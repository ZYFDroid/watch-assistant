package com.tomoon.extensions.notificationpusher;


import android.app.Activity;
import android.app.NotificationManager;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.NotificationManagerCompat;
import android.util.Base64;
import android.view.View;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    public static UUID BtPort = UUID.fromString("c3d3cd23-e209-c3ca-aabd-30addc000000");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void startConnect(View view) {
        if(!isNotificationListenerEnabled(this)){
            openNotificationListenSettings();
            return;
        }
        if(null==NotificationService.mInstance){
            startService(new Intent(this,NotificationService.class));
        }
        else{
            NotificationService.mInstance.isUserStop=true;
            NotificationService.mInstance.stopSelf();
            startService(new Intent(this,NotificationService.class));
        }

    }

    @Override
    public void onBackPressed() {
        finishAndRemoveTask();
    }

    public void selectDevice(View view) {

        startActivity(new Intent(this,SelectDeviceActivity.class));

    }



    public boolean isNotificationListenerEnabled(Context context) {
        Set<String> packageNames = NotificationManagerCompat.getEnabledListenerPackages(this);
        if (packageNames.contains(context.getPackageName())) {
            return true;
        }
        return false;
    }

    public void openNotificationListenSettings() {
        try {
            Intent intent;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP_MR1) {
                intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
            } else {
                intent = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
            }
            startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setNotificationBlock(View view) {
        startActivity(new Intent(this,BlockActivity.class));
    }
}
